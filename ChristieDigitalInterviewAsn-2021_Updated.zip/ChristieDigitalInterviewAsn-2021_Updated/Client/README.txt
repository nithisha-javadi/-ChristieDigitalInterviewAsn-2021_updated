Client (GUI/Angular app)
Requires that npm is installed
1. navigate to the Client directory (where you found this README)
2. open a shell (shift+right click -> Open Powershell in Windows)
3. npm install	(to install the required packages)
4. ng serve --open (to start the app)
5. http://localhost:4200 should automatically open in your browser